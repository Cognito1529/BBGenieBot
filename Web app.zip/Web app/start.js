var webExample = WebApp.getUrl({ command: "index" });

Api.sendMessage({
  text: "🤑 Try our web page",
  reply_markup: { inline_keyboard: [
    [
      // open the any web page on button pressing
      { text: "👉 Click Here 👈", web_app: { url: webExample } },
    ]
  ]}
});
var webExample = WebApp.getUrl({ command: "index" });

Api.sendMessage({
  text: "Try It",

  reply_markup: {
    resize_keyboard: true,
    keyboard: [
      // line 1
      [
        { text: "⚠️ Disclaimer" },
        { text: "Open App", web_app: { url: webExample } }
      ]
    ]
  }
})