Api.sendMessage({
    text: "*Disclaimer*\n\n⚠️ *Error Fetching Response!*\n\nBBGenieBot uses a free API to generate responses. Due to high demand or server limitations, you may occasionally experience errors such as:\n\n❌ *\"Error fetching response!\"*\n⏳ *Slow response times*\n🔄 *Temporary unavailability*\n\nIf this happens, please try again later. We appreciate your patience and understanding! 🚀",
    parse_mode: "Markdown"
});